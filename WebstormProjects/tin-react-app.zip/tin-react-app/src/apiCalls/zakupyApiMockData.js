export const ZakupyList = [
    {
        "_id": 1,
        "straczona": "5000.00",
        "dateFrom": "2000-12-31T23:00:00.000Z",
        "dateTo": "2008-12-31T23:00:00.000Z",
        "Sklep": {
            "_id": 1,
            "adres": "Grojecka 216",
            "DataOtwarcia": "2001-01-31T23:00:00.000Z"
        },
        "Klient": {
            "_id": 1,
            "firstName": "Jan",
            "lastName": "Kowalski",
            "wiek": "13",
            "Plec": "13",
        }
    }
]
export const ZakupyDetails = [
    {
        "_id": 1,
        "straczona": "5000.00",
        "dateFrom": "2000-12-31T23:00:00.000Z",
        "dateTo": "2008-12-31T23:00:00.000Z",
        "Sklep": {
            "_id": 1,
            "adres": "Grojecka 216",
            "DataOtwarcia": "2001-01-31T23:00:00.000Z"
        },
        "Klient": {
            "_id": 1,
            "firstName": "Jan",
            "lastName": "Kowalski",
            "wiek": "13",
            "Plec": "13",
        }
    }
]