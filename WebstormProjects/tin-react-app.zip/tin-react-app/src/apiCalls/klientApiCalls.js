import {klientList,klientDetailList} from "./klientApiMockData";
const klientBaseUrl ='http://localhost:3000/api/klients'
export function getKlientApiCall()
{
   const promise = fetch(klientBaseUrl);
    return promise;
}

export function getKlientByIdApiCall(klientId)
{
   const url = klientBaseUrl+'/'+klientId;
   const promise = fetch(url);
   return promise;
}