export const klientList = [
    {
        "_id": 1,
        "firstName": "Jan",
        "lastName": "Kowalski",
        "wiek": "13",
        "plec": "M",
    },
    {
        "_id": 2,
        "firstName": "Adam",
        "lastName": "Zieliński",
        "wiek": "13",
        "plec": "M",
    }
]
export const klientDetailList = [
    {
        "_id": 1,
        "firstName": "Jan",
        "lastName": "Kowalski",
        "wiek": "13",
        "plec": "M",
    },
    {
        "_id": 2,
        "firstName": "Adam",
        "lastName": "Zieliński",
        "wiek": "13",
        "plec": "M",
    }
]