export const sklepList = [
    {
        "_id": 1,
        "adres": "Grojecka 216",
        "DataOtwarcia": "01-12-2012",
    },
    {
        "_id": 2,
        "adres": "Wagonowia 92",
        "DataOtwarcia": "01-12-2015",
    }
]
export const sklepDetailList = [
    {
        "_id": 1,
        "adres": "Grojecka 216",
        "DataOtwarcia": "01-12-2012",
    },
    {
        "_id": 2,
        "adres": "Wagonowia 92",
        "DataOtwarcia": "01-12-2015",
    }
]