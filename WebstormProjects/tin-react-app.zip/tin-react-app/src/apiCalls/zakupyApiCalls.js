import {ZakupyList,ZakupyDetails} from './zakupyApiMockData'
const klientBaseUrl ='http://localhost:3000/api/zakups'
export function getZakupyApiCall()
{
    const promise = fetch(klientBaseUrl);
    return promise;
}

export function getZakupyByIdApiCall(zakupyId)
{
    const zak = ZakupyDetails.find(zakupy => zakupy._id === zakupyId)
    return zak;
}
