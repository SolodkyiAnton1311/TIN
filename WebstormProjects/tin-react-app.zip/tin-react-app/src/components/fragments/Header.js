import React from "react";

function Header(){
    return (
        <header>
            <h1>Sieć sklepów Truskawka</h1>
            <img src="/img/image.png" alt="Truskawka" />

        </header>
    )
}

export default Header;