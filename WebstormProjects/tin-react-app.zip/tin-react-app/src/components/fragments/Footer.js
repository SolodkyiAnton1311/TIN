import React from "react";

function Footer() {
    return (
        <footer>
            Solodkyi Anton s20738
        </footer>
    )
}

export default Footer;