import React from 'react'
import {Link} from "react-router-dom";
import {getKlientApiCall} from "../../apiCalls/klientApiCalls";
import KlientListTable from "./KlientListTable";

class KlientList extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            error: null,
            isLoaded: false,
            klients: []
        }
    }

    componentDidMount() {
        this.fetchKlientList()
    }

    fetchKlientList = () => {
        getKlientApiCall()
            .then(res => res.json())
            .then(
                (data) => {
                    this.setState({
                        isLoaded: true,
                        klients: data
                    });
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    })
                }
            )
    }

    render() {
        const { error, isLoaded, klients } = this.state
        let content;

        if (error) {
            content = <p>Błąd: {error.message}</p>
        } else if (!isLoaded) {
            content = <p>Ładowanie danych klientow...</p>
        } else {
            content = <KlientListTable klientList={klients} />
        }

        return (
            <main>
                <h2>Lista klientow</h2>
                {content}
                <p className="section-buttons">
                    <Link to="/klients/add" className="button-add">Dodaj nowego Klienta</Link>
                </p>
            </main>
        )
    }
}


export default KlientList