import React from "react";

function KlientDetailData(props)
{
    const klients = props.klientData
    return(
        <React.Fragment>
            <p>Imie:{klients.name}</p>
            <p>Nazwisko:{klients.lastName}</p>
            <p>Wiek:{klients.wiek}</p>
            <p>Plec:{klients.plec}</p>
        </React.Fragment>
    )
}
export default KlientDetailData