import React from "react";

function MainContent() {
    return (
        <main>
            <h2>Strona Glówna</h2>
            <p>Witamy, tutaj znajdzieś kto, gzie i kiedy robił zakupy</p>
        </main>
    )
}

export default MainContent;