INSERT INTO `Klient` (`Imie`, `Nazwisko`, `Wiek`, `Plec`) VALUES ('Anton', 'Solodkyi', '21', 'M');
INSERT INTO `Sklep` (`Adresa`, `Data_otwarcia`) VALUES ('Grojecka 194', '2016-12-08');
INSERT INTO `sklep_klient` (`id_sklep`, `id_klient`, `data_ostatniego_wizutu_klienta`, `data_nastepnego_wizytu`, `straczona_summa`) VALUES ('1', '1', '2021-12-01', '2021-11-03', '100');