const express = require('express');
const router = express.Router();
const klientControler = require('../controllers/ZakupyControler');
router.get('/',klientControler.showKlientList);
router.get('/add',klientControler.showAddKlientForm);
router.get('/details/:zakupyId',klientControler.showKlientDetails);
router.get('/edit/:zakupyId',klientControler.editZakupy);
module.exports =router;
