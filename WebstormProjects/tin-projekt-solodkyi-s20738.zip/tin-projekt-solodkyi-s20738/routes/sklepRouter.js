const express = require('express');
const router = express.Router();
const sklepController = require('../controllers/SklepControler');
router.get('/',sklepController.showKlientList);
router.get('/add',sklepController.showAddKlientForm);
router.get('/details/:sklepId',sklepController.showKlientDetails);
router.get('/edit/:sklepId',sklepController.editSklep);
module.exports =router;
