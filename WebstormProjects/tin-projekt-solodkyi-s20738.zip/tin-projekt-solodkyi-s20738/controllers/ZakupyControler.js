const Zakupy = require("../repository/mysql2/ZakupyRepository");

exports.showKlientList=(req,res,next) => {
    Zakupy.getZakupy()
        .then(zakups => {
            res.render('pages/Zakupy/list', {
                zakups:zakups,
                navLocation:'Zakupy'
            });
        });
}
exports.showAddKlientForm=(req,res,next) => {
    res.render('pages/Zakupy/form',{});
}
exports.showKlientDetails=(req,res,next) => {
    res.render('pages/Zakupy/details',{});
}
exports.editZakupy=(req,res,next) => {
    res.render('pages/Zakupy/details',{});
}