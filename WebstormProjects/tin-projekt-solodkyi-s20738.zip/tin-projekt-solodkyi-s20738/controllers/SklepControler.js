const SklepRepository = require("../repository/mysql2/SklepRepository");
exports.showKlientList=(req,res,next) => {
        SklepRepository.getSklep()
        .then(skleps => {
            res.render('pages/Sklepy/list', {
                skleps:skleps,
                navLocation:'Sklep'
            });
        });
}
exports.showAddKlientForm=(req,res,next) => {
    res.render('pages/Sklepy/form',{});
}
exports.showKlientDetails=(req,res,next) => {
    res.render('pages/Sklepy/details',{});
}
exports.editSklep=(req,res,next) => {
    res.render('pages/Sklepy/edit',{});
}