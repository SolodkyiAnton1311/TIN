const KlientRepository = require("../repository/mysql2/KlientRepository");
exports.showKlientList = (req, res, next) => {
    KlientRepository.getKlients()
        .then(klienci => {
            res.render('pages/Klient/list', {
                klienci:klienci,
                navLocation:'klient'
            });
        });
}

exports.showAddKlientForm=(req,res,next) => {
    res.render('pages/Klient/form',{
        klient:{},
        pageTitle:'Nowy Klient',
        formMode:'createNew',
        bntLable:'Dodaj klienta',
        formAction:'/klient/add',
        navLocation:'klient'
    });
}
exports.showKlientDetails=(req,res,next) => {
    const klientId = req.params.klientId;
    KlientRepository.getKlientsById(klientId).then(klient =>{
        res.render('pages/Klient/form',{
            klient:klient,
        formMode:'',
        pageTitle:'Szegoly Klienta'

    });})

};
exports.showKlientEditForm=(req, res, next) => {
    const klientId = req.params.klientId;
    KlientRepository.getKlientsById(klientId).then(klient =>{
        res.render('pages/Klient/form',{
            klient: klient,
            formMode: 'edit',
            pageTitle: 'Edycja klienta',
            btnLabel: 'Edytuj klienta',
            formAction: '/klient/edit/',
            navLocation: 'klient'
        });
    })

};
